import GeneMaster as gm

dna = gm.DNA('CAGTGACTGGACT')
print(dna.visualize)